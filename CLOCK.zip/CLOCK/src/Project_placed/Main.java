package Project_placed;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Testing");
		MyWindow w=new MyWindow();
		
	
	

	}

}
