module CLOCK {
	requires java.desktop;
}